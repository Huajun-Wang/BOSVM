clear all; clc; close all;
addpath(genpath(pwd));
load Austrain
X      = normalization(X,2);
y      = Y;  y(y~=1)= -1;  
[M,n]  = size(X);         
X      = normalization(X,2); % normalize the data
 
% randomly split the data into training and testing data
m  = ceil(0.9*M);  mt = M-m;       I  = randperm(M);
Tt = I(1:mt);      Xt = X(Tt,:);   yt = y(Tt);   % testing  data 
T  = I(1+mt:end);  X  = X(T,:);    y  = y(T,:);  % training data
 

fprintf(' ------------------------------------------------------------------------\n');
fprintf('      kappa      rho     Iter      TACC       ACC       NSV        TIME\n');
fprintf(' ------------------------------------------------------------------------\n');

for i          = -4:1:4
    pars.kappa     = 2^i; 
    for  j     = -4:1:4
    pars.rho = 2^j;
    out        = CSLSVM(X,y,pars); 
    wb         = out.wb;
    if out.flag==2 
       ACC    = accuracy(Xt,yt,wb);%testing set  
       fprintf(' | %5.2f  |  %5.2f  |  %3d  |  %6.4f  |  %6.4f  |  %4d  |  %5.3fsec  |\n',...
       pars.kappa, pars.rho, out.iter, out.acc,  ACC,out.nsv,out.time);
    end
    end
end 

