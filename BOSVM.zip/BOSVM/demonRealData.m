clear all; clc; close all;
addpath(genpath(pwd));
load Australian

fprintf(' ------------------------------------------------------------------------\n');
fprintf('lambda     sigma     lambda1      TACC       ACC        TIME\n');
fprintf(' ------------------------------------------------------------------------\n');

for i          = -4:1:4
    pars.lambda     = 2^i; 
    for j         = -1:1:1
    pars.lambda1     = 10^j; 
    for  k    = -4:1:4
    pars.sigma = 2^k;
    out        = BOSVM(X,y,pars); 
    bbeta0         = out.bbeta0;
    if out.flag==2 
       ACC    = accuracy(Xt,yt,bbeta0);%testing set  
       fprintf('| %5.2f  |  %5.2f  |  %5.2f |  %6.4f  |  %6.4f |  %5.3fsec  |\n',...
          pars.lambda, pars.sigma, pars.lambda1, out.acc, ACC,out.time);
    end
end
end 

end