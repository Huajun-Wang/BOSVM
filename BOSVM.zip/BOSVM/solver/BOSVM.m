function  out= BOSVM(X,y,pars)%\kappa\rho \upsilon \psi
% Inputs:
%       X    -- the sample data, dimension, \in\R^{m-by-n}; (required)
%       y    -- the classes of the sample data, \in\R^m; (required)
%               y_i \in {+1,-1}, i=1,2,...,m
%       pars -- parameters (optional)
%
% pars:     Parameters are all OPTIONAL
%               pars.upsilon   --  Starting point of alpha \in\R^m,  (default, zeros(m,1))
%               pars.kappa  --  A positive scalar in (2^-4,2^-6,...,2^4).(default, 1)
% %             pars.rho      --  A positive scalar in (sqrt(2)^-4,...,sqrt(2)^4).(default, 1)
%               pars.maxit   --  Maximum number of iterations, (default,1000)
%               pars.tol     --  Tolerance of the halting condition, (default,1e-3)
%
% Outputs:
%     Out.iter:          Number of iterations
%     Out.time:          CPU time
%     Out.wb:            The solution of the primal problem, namely the classifier
%     Out.r:             The solution r
%     Out.ups:           The solution upsilon
%     Out.alpha:         The solution alpha
%     Out.nsv:           Number of support vectors
%     Out.s:             Sparsity level of the solution Out.alpha
%     Out.acc:           Classification accuracy
%     Out.error:         Classification error




if nargin<3;               pars  = [];                             end
if isfield(pars,'maxit');  maxit = pars.maxit; else; maxit = 1e3;  end
if isfield(pars,'rho');     rho = pars.rho; else; rho = 1;    end
if isfield(pars,'tol');    tol   = pars.tol;   else; tol   = 1e-3; end
if isfield(pars,'kappa'); kappa= pars.kappa;else; kappa     = 1;    end
[m,n]  = size(X);
 w=zeros(n,1);%w      = ones(n,1)/100
ups    = zeros(m,1);
upsrho = ups;
B      = GetB(y,m,n);
R      = y.*X;
h      = 1-R*w;
b      = 0;   %b= 1 or -1;
z      = h-b*y;
theta  = ones(1,4);
Fnorm  = @(var)norm(var)^2;
to     = tic;
flag   = 0;
for iter  = 1:1:maxit
    % update B -------------------------------------
    if kappa/rho>=9/32
       con = sqrt(2*kappa/rho);
       B   = find(z >0 & z <= con);
    else
       B1   = find(z>0 & z<8*kappa/3*rho);
       B2   = find(z>=(8*kappa/3*rho) & z<1/2);
       B    = union(B1,B2);
     end
    % update r -------------------------------------
    if kappa/rho>=9/32
         r = Prox(z,kappa,rho,B);
    else
         r = Prox1(z,kappa,rho,B1,B2);
    end
    % update w--------------------------------------
    tmp    = 1 - r - upsrho; 
    v      = tmp - b*y;
    nB     = nnz(B);
    RB     = R(B,:);
    if min(n,nB)< 1e3
        RBt     = RB';
        if  n  <= nB
            RRB = RBt*RB;
            RRB(1:1+n:end) = RRB(1:1+n:end) + 1/rho;
            w   = RRB\(RBt*v(B)-0.0001*sign(w));
        else
            if nB >0
                RRB = RB *RBt;
                RRB(1:1+nB:end) = RRB(1:1+nB:end) + 1/rho;
                w  = RBt*(RRB\v(B));
            else
                w  = -ones(n,1); B=1;
            end
        end
    else
        if  n  <= nB
            w = my_cg(RB,rho,(v(B)'*RB)',n,1);
        else
            wB = my_cg(RB,rho,v(B),nB,2);
            w  = (wB'*RB)';
        end
    end

    % update b-------------------------------------
    Rw     = R*w;
    b      = mean((tmp(B)-Rw(B)).*y(B));


    % update upsilon-------------------------------
    upsB   = ups(B);
    ups    = zeros(m,1);
    omega  = Rw + r - 1 + b*y;
    upsB   = upsB + rho * omega(B);
    ups(B) = upsB;


     % stopping crterion --------------------------
    upsrho = ups/rho;
    rups   = r  - upsrho;
    ind    = (rups<=0 | rups>sqrt(2*kappa/rho));

    theta(1) = Fnorm(w'+ upsB'*RB)/(1+Fnorm(w));
    theta(2) = abs(y(B)'*upsB)/(1+nB);
    theta(3) = Fnorm(omega)/(m+Fnorm(Rw)); %
    if kappa/rho>=9/32
    theta(4) = Fnorm(r-rups.*ind)/(1+Fnorm(r));
    else
    theta(4) = Fnorm(r - Prox1(z,kappa,rho,B1,B2))/(1+Fnorm(r));
    end
    error    = max(theta);
     CPU     = toc(to);
    ACC      = 1-nnz(sign(y.*Rw+b)-y)/length(y);
   tACC(iter)= ACC;
    if error < tol && ACC>0.5; flag=2; break;  end

    z        = rups - omega;
    rho0     = min(z(z>0));
    if isempty(rho0); rho0 = 1e-8; end

    if mod(iter,10)==0
        if theta(3) > 1e-3
           rho = min(rho*2,10);
        elseif theta(1) > 1e-3
           rho = min(max(0.01,rho/1.25),5);
        end
    end
 if    m<n || m>10000
    if rho > 2*kappa/rho0^2  % exclude zero solutions
       rho = 1.9*kappa/rho0^2;
    end
 end

 if iter>5 && m>n && m<=10000

 if std(tACC(iter-3:iter))<=1e-3
  Cons = sqrt(2*kappa/rho);  m0   = max(20,2*n);
  B0   = find(z >0 & z <= Cons);

 if nnz(B0)<5 || nnz(B0)>=m0
    flag=1;  z1 = z(find(z>0));
 if nnz(z1)>m0
    s  = mink(z1,m0);    rho = min(2*kappa/s(m0)^2,10000);
 else
 [~,B] = mink(abs(z),m0); flag=0;
  end
  end
  end
  end
end
% fprintf('----------------------------------------------------\n');

out.iter = iter;
out.time = CPU;
out.wb   = [w;b];
out.r    = r;
out.ups  = ups;
out.nsv  = nB;
out.acc  = ACC;
out.error= error;
out.flag = flag;
end

% proxiaml-----------------------------------------------------------------
function r = Prox(z,kappa,rho,B)
if isempty(B)
    tmp1 = sqrt(2*kappa/rho);
    B    = find(z >0 & z <= tmp1);
    r    = z;
    r(B) = 0;
   else
    r    = z;
    r(B) = 0;
 end

end

function r = Prox1(z,kappa,rho,B1,B2)
   B=union(B1, B2);
if isempty(B)
    tmp1 = sqrt(2*kappa/rho);
    B    = find(z >0 & z <= tmp1);
    r    = z;
    r(B) = 0;
else
    r    = z;
    r(B1)= 0;
    r(B2)= (18*z(B2)-27*kappa/rho)/(18-64*kappa/rho);
 end

end

% %%% -----------------------------------------------------------------
function B = GetB(y,m,n)
if  m>n
s0      = ceil(n*(log(m/n))^2);
B1      = find(y==1);  nB1= nnz(B1);
B2      = find(y==-1); nB2= nnz(B2);
if  nB1 < s0
    B  = [B1; B2(1:(s0-nB1))];
elseif nB2 < s0
    B  = [B1(1:(s0-nB2)); B2];
else
    B  = [B1(1:ceil(s0/2)); B2(1:(s0-ceil(s0/2)))];
end
B      = sort(B(1:s0));
else
    B  = 1:length(y);
end
end

% Conjugate gradient method-------------------------------------------------
function x = my_cg(RB,rho,b,n,flag)
    x = zeros(n,1);
    r = b;
    e = sum(r.*r);
    t = e;
    for i = 1: 50
        if e < 1e-10*t; break; end
        if  i == 1
            p = r;
        else
            p = r + (e/e0)*p;
        end
        if  flag==1
            w  = p/rho  + ((RB*p)'*RB)';
        else
            w  = p/rho  + RB*(p'*RB)';
        end
        a  = e/sum(p.*w);
        x  = x + a * p;
        r  = r - a * w;
        e0 = e;
        e  = sum(r.*r);
    end

end