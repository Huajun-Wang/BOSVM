function  out= BOSVM(X,y,pars)%\lambda\sigma \tau \psi
% Inputs:
%       X    -- the sample data, dimension, \in\R^{m-by-n}; (required)
%       y    -- the classes of the sample data, \in\R^m; (required)
%               y_i \in {+1,-1}, i=1,2,...,m
%       pars -- parameters (optional)
%
% pars:     Parameters are all OPTIONAL
%               pars.tau   --  Starting point of tau \in\R^m,  (default, zeros(m,1))
%               pars.lambda  --  A positive scalar in (2^-4,2^-6,...,2^4).(default, 1)
% %             pars.sigma      --  A positive scalar in (2^-4,...,2^4).(default, 1)
%               pars.maxit   --  Maximum number of iterations, (default,1000)
%               pars.tol     --  Tolerance of the halting condition, (default,1e-3)
%
% Outputs:
%     Out.iter:          Number of iterations
%     Out.time:          CPU time
%     Out.bbeta0:        The solution of the primal problem, namely the classifier
%     Out.h:             The solution h
%     Out.tau:           The solution tau
%     Out.alpha:         The solution alpha
%     Out.nsv:           Number of support vectors
%     Out.s:             Sparsity level of the solution Out.alpha
%     Out.acc:           Training classification accuracy
%     Out.error:         Classification error




if nargin<3;               pars  = [];                             end
if isfield(pars,'lambda'); lambda= pars.lambda;else; lambda     = 1;    end
if isfield(pars,'maxit');  maxit = pars.maxit; else; maxit = 1e3;  end
if isfield(pars,'sigma');     sigma = pars.sigma; else; sigma = 1;    end
if isfield(pars,'tol');    tol   = pars.tol;   else; tol   = 1e-3; end
if isfield(pars,'lambd1'); lambda1= pars.lambda1;else; lambda1     = 10^-4;    end
[m,n]  = size(X);
 beta=zeros(n,1);%beta  = ones(n,1)/100
tau    = zeros(m,1);
tausigma = tau;
M      = GetM(y,m,n);%
N      = y.*X;
g      = 1-N*beta;
beta0      = 0;   %beta0= 1 or -1;
q      = g-beta0*y;
eps  = ones(1,4);
Fnorm  = @(var)norm(var)^2;
to     = tic;
flag   = 0;
for iter  = 1:1:maxit
    % update M -------------------------------------
    if lambda/sigma>=9/32
       con = sqrt(2*lambda/sigma);
       M   = find(q >0 & q <= con);
    else
       M1   = find(q>0 & q<8*lambda/3*sigma);
       M2   = find(q>=(8*lambda/3*sigma) & q<3/4);
       M    = union(M1,M2);
     end
    % update h -------------------------------------
    if lambda/sigma>=9/32
         h = Prox(q,lambda,sigma,M);
    else
         h = Prox1(q,lambda,sigma,M1,M2);
    end
    % update beta--------------------------------------
    tmp    = 1 - h - tausigma; 
    v      = tmp - beta0*y;
    nM     = nnz(M);
    NM     = N(M,:);
    if min(n,nM)< 1e3
        NMt     = NM';
        if  n  <= nM
            NNM = NMt*NM;
            NNM(1:1+n:end) = NNM(1:1+n:end) + 1/sigma;
            beta   = NNM\(NMt*v(M)-lambda1*sign(beta));
        else
            if nM >0
                NNM=NNM; sigma=sigma;
                ATt=NMt;NM=NM;nT=nM;
 %               NNM(1:1+nM:end) = NNM(1:1+nM:end) + 1/sigma;
%                beta  = NMt*(NNM\v(M));
               NNM = NM *NMt;               
                beta  = (eye(n)-sigma*NMt*inv(eye(nT)+sigma*NNM)*NM)*(sigma*NMt*v(M)-lambda1*sign(beta));    
                
            else
                beta  = -ones(n,1); M=1;
            end
        end
    else
        if  n  <= nM
            beta = my_cg(NM,sigma,(v(M)'*NM)',n,1);
        else
            betaM = my_cg(NM,sigma,v(M),nM,2);
            beta  = (betaM'*NM)';
        end
    end

    % update beta0-------------------------------------
    Nbeta     = N*beta;
    beta0      = mean((tmp(M)-Nbeta(M)).*y(M));


    % update tau-------------------------------
    tauM   = tau(M);
    tau    = zeros(m,1);
    omega  = Nbeta + h - 1 + beta0*y;
    tauM   = tauM + sigma * omega(M);
    tau(M) = tauM;


     % stopping crterion --------------------------
    tausigma = tau/sigma;
    rtau   = h  - tausigma;
    ind    = (rtau<=0 | rtau>sqrt(2*lambda/sigma));%eps

    eps(1) = Fnorm(beta'+ tauM'*NM+lambda1*sign(beta)')/(1+Fnorm(beta));
    eps(2) = abs(y(M)'*tauM)/(1+nM);
    eps(3) = Fnorm(omega)/(m+Fnorm(Nbeta)); %
    if lambda/sigma>=9/32
    eps(4) = Fnorm(h-rtau.*ind)/(1+Fnorm(h));
    else
    eps(4) = Fnorm(h - Prox1(q,lambda,sigma,M1,M2))/(1+Fnorm(h));
    end
    error    = max(eps);
     CPU     = toc(to);
    ACC      = 1-nnz(sign(y.*Nbeta+beta0)-y)/length(y);
   tACC(iter)= ACC;
    if error < tol && ACC>0.5; flag=2; break;  end

    q        = rtau - omega;
    sigma0     = min(q(q>0));
    if isempty(sigma0); sigma0 = 1e-8; end

    if mod(iter,10)==0
        if eps(3) > 1e-3
           sigma = min(sigma*2,10);
        elseif eps(1) > 1e-3
           sigma = min(max(0.01,sigma/1.25),5);
        end
    end
 if    m<n || m>10000
    if sigma > 2*lambda/sigma0^2  % exclude zero solutions
       sigma = 1.9*lambda/sigma0^2;
    end
 end

 if iter>5 && m>n && m<=10000

 if std(tACC(iter-3:iter))<=1e-3
  Cons = sqrt(2*lambda/sigma);  m0   = max(20,2*n);
  M0   = find(q >0 & q <= Cons);

 if nnz(M0)<5 || nnz(M0)>=m0
    flag=1;  q1 = q(find(q>0));
 if nnz(q1)>m0
    s  = mink(q1,m0);    sigma = min(2*lambda/s(m0)^2,10000);
 else
 [~,M] = mink(abs(q),m0); flag=0;
  end
  end
  end
  end
end
% fprintf('----------------------------------------------------\n');

out.iter = iter;
out.time = CPU;
out.bbeta0   = [beta;beta0];
out.h    = h;
out.tau  = tau;
out.nsv  = nM;
out.acc  = ACC;
out.error= error;
out.flag = flag;
end

% proxiaml-----------------------------------------------------------------
function h = Prox(q,lambda,sigma,M)
if isempty(M)
    tmp1 = sqrt(2*lambda/sigma);
    M    = find(q >0 & q <= tmp1);
    h    = q;
    h(M) = 0;
   else
    h    = q;
    h(M) = 0;
 end

end

function h = Prox1(q,lambda,sigma,M1,M2)
   M=union(M1, M2);
if isempty(M)
    tmp1 = sqrt(2*lambda/sigma);
    M    = find(q >0 & q <= tmp1);
    h    = q;
    h(M) = 0;
else
    h    = q;
    h(M1)= 0;
    h(M2)= (18*q(M2)-27*lambda/sigma)/(18-64*lambda/sigma);
 end

end

% %%% -----------------------------------------------------------------
function M = GetM(y,m,n)
if  m>n
s0      = ceil(n*(log(m/n))^2);
M1      = find(y==1);  nM1= nnz(M1);
M2      = find(y==-1); nM2= nnz(M2);
if  nM1 < s0
    M  = [M1; M2(1:(s0-nM1))];
elseif nM2 < s0
    M  = [M1(1:(s0-nM2)); M2];
else
    M  = [M1(1:ceil(s0/2)); M2(1:(s0-ceil(s0/2)))];
end
M      = sort(M(1:s0));
else
    M  = 1:length(y);
end
end

% Conjugate gradient method-------------------------------------------------
function x = my_cg(NM,sigma,beta0,n,flag)
    x = zeros(n,1);
    h = beta0;
    e = sum(h.*h);
    t = e;
    for i = 1: 50
        if e < 1e-10*t; break; end
        if  i == 1
            p = h;
        else
            p = h + (e/e0)*p;
        end
        if  flag==1
            beta  = p/sigma  + ((NM*p)'*NM)';
        else
            beta  = p/sigma  + NM*(p'*NM)';
        end
        a  = e/sum(p.*beta);
        x  = x + a * p;
        h  = h - a * beta;
        e0 = e;
        e  = sum(h.*h);
    end

end