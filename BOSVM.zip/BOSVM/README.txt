This source code is programmed based on the algorithm described in:

Sparse and robust elastic net support vector machine with bounded concave loss for large-scale problems

Please give credits to this paper if you use the code for your research.
